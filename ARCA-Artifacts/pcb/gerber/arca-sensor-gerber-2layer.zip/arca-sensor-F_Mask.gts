%TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+dfsg-1build4*%
%TF.CreationDate,2026-09-23T23:04:39+07:00*%
%TF.ProjectId,arca-sensor,61726361-2d73-4656-9e73-6f722e6b6963,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+dfsg-1build4) date 2026-09-23 23:04:39*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.900000*%
%ADD11RoundRect,0.100000X-0.850000X-0.850000X0.850000X-0.850000X0.850000X0.850000X-0.850000X0.850000X0*%
%ADD12C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,R2*%
X14270000Y11420000D03*
X14270000Y8880000D03*
%TD*%
%TO.C,R1*%
X14270000Y16500000D03*
X14270000Y13960000D03*
%TD*%
D11*
%TO.C,J1*%
X9190000Y4000000D03*
D10*
X11730000Y4000000D03*
X14270000Y4000000D03*
X16810000Y4000000D03*
%TD*%
D11*
%TO.C,J2*%
X9190000Y19000000D03*
D10*
X11730000Y19000000D03*
X14270000Y19000000D03*
X16810000Y19000000D03*
%TD*%
D12*
%TO.C,@HOLE1*%
X3500000Y19800000D03*
%TD*%
%TO.C,@HOLE0*%
X3500000Y3500000D03*
%TD*%
M02*
